
import time
if __name__ == "__main__":
    print("[burst] stub running; sleeping")
    while True:
        time.sleep(60)
